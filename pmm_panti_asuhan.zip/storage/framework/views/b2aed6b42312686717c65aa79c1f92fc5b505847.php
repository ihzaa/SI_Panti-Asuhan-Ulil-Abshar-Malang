<?php $__env->startSection('judul_halaman',request()->is('*/pengeluaran/tambah*') ? 'Tambah Pengeluaran' : 'Edit pengeluaran'); ?>
<?php $__env->startSection('breadcrumb'); ?>

<li class="breadcrumb-item active"><a href="<?php echo e(route('admin_pengeluaran')); ?>">Pengeluaran</a></li>
<li class="breadcrumb-item active">
    <?php echo e(request()->is('*/pengeluaran/tambah*') ? 'Tambah pengeluaran' : 'Edit pengeluaran'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<form
    action="<?php echo e(request()->is('*/pengeluaran/tambah*') ? route('admin_tambah_pengeluaran'): route('admin_edit_pengeluaran',['id'=>$data['pengeluaran']->id])); ?>"
    method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        Data pengeluaran<span class="text-danger">*</span>
                    </h3>
                </div>
                <div class="card-body" id="card-body-atas">


                    <div class="form-group mt-4">
                        <textarea type="text" class="form-control" id="inputWarning" name="pengeluaran"
                            placeholder="kegiatan pengeluaran"><?php echo e(request()->is('*/pengeluaran/tambah*')?old('nominal'):$data['pengeluaran']->nama_keperluan); ?></textarea>
                        <?php $__errorArgs = ['pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Rp.</span>
                        </div>
                        <input type="text" class="form-control" id="inputWarning11" name="nominal" placeholder="nominal"
                            value="<?php echo e(request()->is('*/pengeluaran/tambah*')?old('pengeluaran'):$data['pengeluaran']->nominal); ?>"
                            required>
                        <?php $__errorArgs = ['nominal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>



                    

                    <div class="form-group">
                        <input type="date" class="form-control" id="inputWarning" name="date"
                            value="<?php echo e(request()->is('*/pengeluaran/tambah*')?old('date'):\Carbon\Carbon::parse($data['pengeluaran']->created_at)->format("Y-m-d")); ?>"
                            required>

                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>




                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-2 mx-auto mb-3">
            <button class="btn btn-primary btn-block" type="submit">Simpan</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>

<!-- bs-custom-file-input -->
<script src="<?php echo e(asset('admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
<script>
    bsCustomFileInput.init();
    $(document).ready(function(){
        var n = parseInt($("#inputWarning11").val().replace(/\D/g,''),10);
        $("#inputWarning11").val(n.toLocaleString());
    })
    $("#inputWarning11").on('keyup', function(){
        var n = parseInt($(this).val().replace(/\D/g,''),10);
        $(this).val(n.toLocaleString());
    });
    // function readURL(input) {
    //     if (input.files && input.files[0]) {
    //         var reader = new FileReader();

    //         reader.onload = function(e) {
    //             $('#blah').attr('src', e.target.result);
    //         }

    //         reader.readAsDataURL(input.files[0]); // convert to base64 string
    //     }
    // }

    // $("#imgInp").change(function() {
    //     readURL(this);
    // });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/admin/pages/Pengeluaran/tambah-edit.blade.php ENDPATH**/ ?>