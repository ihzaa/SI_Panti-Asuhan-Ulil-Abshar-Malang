<?php $__env->startSection('konten'); ?>
<section class="hero-wrap hero-wrap-2 js-fullheight"
    style="background-image: url(<?php echo e(asset('aspiration/images/bg_2.jpg')); ?>);" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
            <div class="col-md-9 ftco-animate pb-5 text-center">
                <h2 class="mb-3 bread">Blog</h2>
                <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i
                                class="ion-ios-arrow-forward"></i></a></span> <span>Blog <i
                            class="ion-ios-arrow-forward"></i></span></p>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 ftco-animate">
                <div class="row">
                    <?php $__currentLoopData = $data['blogs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 d-flex ftco-animate">
                        <div class="blog-entry align-self-stretch d-md-flex">
                            <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>" class="block-20"
                                style="background-image: url('assets/aspiration/images/image_1.jpg');">
                            </a>
                            <div class="text d-block pl-md-4">
                                <div class="meta mb-3">
                                    <div><a
                                            href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>"><?php echo e(\Carbon\Carbon::parse($d->created_at)->formatLocalized("%A, %d %B %Y")); ?></a>
                                    </div>
                                    <div><a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>">-
                                            <?php echo e($d->users->name); ?></a></div>
                                </div>
                                <h3 class="heading"><a
                                        href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>"><?php echo e($d->judul); ?></a>
                                </h3>
                                <p><?php echo e(preg_replace('/<[^>]*>/', '', substr($d->konten,0,150))); ?></p>
                                <p><a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>"
                                        class="btn btn-primary py-2 px-3">Read more</a></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($data['blogs']->links()); ?>

                </div>
            </div> <!-- .col-md-8 -->
            <div class="col-lg-4 sidebar ftco-animate">
                <div class="sidebar-box">
                    <form action="#" class="search-form">
                        <div class="form-group">
                            <span class="icon ion-ios-search"></span>
                            <input type="text" class="form-control" placeholder="Type a keyword and hit enter">
                        </div>
                    </form>
                </div>
                <div class="sidebar-box ftco-animate">
                    <h3 class="heading-2">Categories</h3>
                    <ul class="categories">
                        <?php $__currentLoopData = $data['kategoris']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="#"><?php echo e($d->nama); ?>

                                <?php if($d->blog_count != 0): ?>
                                <span>(<?php echo e($d->blog_count); ?>)</span>
                                <?php endif; ?>
                            </a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="sidebar-box ftco-animate">
                    <h3 class="heading-2">Tag Cloud</h3>
                    <div class="tagcloud">
                        <a href="#" class="tag-cloud-link">donate</a>
                        <a href="#" class="tag-cloud-link">charity</a>
                        <a href="#" class="tag-cloud-link">non-profit</a>
                        <a href="#" class="tag-cloud-link">organization</a>
                        <a href="#" class="tag-cloud-link">child</a>
                        <a href="#" class="tag-cloud-link">abuse</a>
                        <a href="#" class="tag-cloud-link">help</a>
                        <a href="#" class="tag-cloud-link">volunteer</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> <!-- .section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/blog.blade.php ENDPATH**/ ?>