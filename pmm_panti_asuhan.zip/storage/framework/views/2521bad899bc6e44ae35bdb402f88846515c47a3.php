<div class="sidebar-box">
    <form action="<?php echo e(route('frontend_blog_cari',['cari'=>'_|_cari_|_'])); ?>" method="GET" id="form_cari"
        class="search-form">
        <div class="form-group">
            <span class="icon ion-ios-search"></span>
            <input type="text" id="text_cari" class="form-control"
                placeholder="Tulis yang ingin dicari lalu tekan enter">
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/Blog/Components/searchBar.blade.php ENDPATH**/ ?>