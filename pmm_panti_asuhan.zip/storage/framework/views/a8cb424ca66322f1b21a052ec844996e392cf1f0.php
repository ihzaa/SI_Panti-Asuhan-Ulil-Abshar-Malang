<div class="sidebar-box ftco-animate">
    <h3 class="heading-2">Kategori</h3>
    <ul class="categories">
        <?php $__currentLoopData = $data['kategoris']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('frontend_blog_per_kategori',['kat'=>$d->id])); ?>"><?php echo e($d->nama); ?>

                <?php if($d->blog_count != 0): ?>
                <span>(<?php echo e($d->blog_count); ?>)</span>
                <?php endif; ?>
            </a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/Blog/Components/categoris.blade.php ENDPATH**/ ?>