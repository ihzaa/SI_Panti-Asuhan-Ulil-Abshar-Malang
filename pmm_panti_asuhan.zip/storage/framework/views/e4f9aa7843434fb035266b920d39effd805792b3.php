<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>pengeluaran</title>
    <link rel="stylesheet" href="<?php echo e(url('/assets/css/bootstrap.min.css')); ?>">
</head>

<body>
    <div class="container-fluid">
        
        
        
        
        <img src="<?php echo e(url('/assets/aspiration/images/logo.jpg')); ?>" alt="" style="position: relative;" height="200">
        <div style="position: absolute;top: 70px;left: 300px;">
            <h4>Panti Asuhan Ulil Abshar Putra Muhammadiyah Malang</h4>
            <h6>Laporan <?php echo e($data['keterangan']); ?></h6>
        </div>
        
        
        
        <table class='table table-bordered'>
            <thead>
                <tr>
                    <th style="width: 5%;">No</th>
                    <th style="width: 20%;">pengeluaran</th>
                    <th style="width: 20%;">tanggal</th>
                    <th style="width: 20%;">Nominal</th>


                </tr>
            </thead>
            <tbody>
                <?php
                $i=1;
                $total = 0;
                ?>
                <?php $__currentLoopData = $data['pengeluaran']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($p->nama_keperluan); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($p->created_at)->format('d-m-Y')); ?></td>
                    <td>Rp. <?php echo e(number_format($p->nominal, 0, '.', '.')); ?></td>

                    <?php
                    $total += $p->nominal;
                    ?>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="3" class="text-right"><strong>Total</strong></td>
                    <td colspan="3"><strong>Rp. <?php echo e(number_format($total, 0, '.', '.')); ?></strong></td>
                </tr>

            </tbody>
        </table>
        
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/Exportable/Pengeluaran.blade.php ENDPATH**/ ?>