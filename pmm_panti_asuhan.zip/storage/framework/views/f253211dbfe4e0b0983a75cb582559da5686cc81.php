<?php echo $__env->yieldContent('foto_bg'); ?>
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
            <div class="col-md-9 ftco-animate pb-5 text-center">
                <?php echo $__env->yieldContent('isiHeader'); ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/template/header.blade.php ENDPATH**/ ?>