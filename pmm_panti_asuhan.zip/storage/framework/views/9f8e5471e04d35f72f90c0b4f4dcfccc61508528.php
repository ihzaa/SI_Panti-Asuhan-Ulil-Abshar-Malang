<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>pengeluaran</title>
    <link rel="stylesheet" href="<?php echo e(url('/assets/css/bootstrap.min.css')); ?>">
</head>

<body>
    <div class="container-fluid">
        
        
        
        
        <img src="<?php echo e(url('/assets/aspiration/images/logo.jpg')); ?>" alt="" style="position: relative;" height="200">
        <div style="position: absolute;top: 70px;left: 300px;">
            <h4>Panti Asuhan Ulil Abshar Putra Muhammadiyah Malang</h4>
            <h6>Laporan <?php echo e($data['keterangan']); ?></h6>
        </div>
        
        
        
        <table class='table table-bordered'>
            <thead>
                <tr>
                    <th style="width: 5%;">No</th>
                    <th style="width: 20%;">Bulan</th>
                    <th style="width: 20%;">Pemasukan</th>
                    <th style="width: 20%;">Pengeluaran</th>


                </tr>
            </thead>
            <tbody>
                <?php
                $i=1;
                $index = 0;
                $totalPemasukan = 0;
                $totalPengeluaran = 0;
                $total = 0;
                ?>
                <?php $__currentLoopData = $data['hasil']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($data['bulan'][$k]); ?> <?php echo e($data['tahun']); ?> </td>
                    <td>Rp. <?php echo e(number_format($d[0], 0, '.', '.')); ?></td>
                    <td>Rp. <?php echo e(number_format($d[1], 0, '.', '.')); ?></td>
                    <?php
                    $totalPemasukan += $d[0];
                    $totalPengeluaran +=$d[1];
                    ?>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

                <tr>
                    <td colspan="2" class="text-center"><strong>Total</strong></td>
                    <td colspan="1"><strong>Rp. <?php echo e(number_format($totalPemasukan, 0, '.', '.')); ?></strong></td>
                    <td colspan="1"><strong>Rp. <?php echo e(number_format($totalPengeluaran, 0, '.', '.')); ?></strong></td>
                </tr>

            </tbody>
        </table>
        
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/Exportable/keuanganTahun.blade.php ENDPATH**/ ?>