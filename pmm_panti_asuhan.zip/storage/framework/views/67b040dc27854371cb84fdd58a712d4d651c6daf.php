<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container-fluid px-lg-5">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><?php echo e(config('app.name')); ?></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
            aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
                
                <li class="nav-item <?php echo e(request()->is('/') ? "active":""); ?>"><a href="<?php echo e(route('home')); ?>" class="nav-link">Beranda</a>
                </li>
                <li class="nav-item <?php echo e(request()->is('about*') ? "active":""); ?>"><a href="<?php echo e(route('about')); ?>" class="nav-link">Tentang kami</a></li>
                <li class="nav-item <?php echo e(request()->is('produk*') ? "active":""); ?>"><a href="<?php echo e(route('produk')); ?>" class="nav-link">Produk</a></li>
                <li class="nav-item <?php echo e(request()->is('profil_anak*') ? "active":""); ?>"><a href="<?php echo e(route('profil_anak')); ?>" class="nav-link">Profil Anak</a></li>
                <li class="nav-item <?php echo e(request()->is('blog*') ? "active":""); ?>"><a href="<?php echo e(route('frontend_blog_index')); ?>"
                        class="nav-link">Blog</a></li>
                <li class="nav-item <?php echo e(request()->is('contact*') ? "active":""); ?>"><a href="<?php echo e(route('frontend_contact')); ?>" class="nav-link">Kontak</a></li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/template/navbar.blade.php ENDPATH**/ ?>