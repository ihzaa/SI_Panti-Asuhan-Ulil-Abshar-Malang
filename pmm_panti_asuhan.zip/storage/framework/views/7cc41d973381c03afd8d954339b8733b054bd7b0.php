


<?php $__env->startSection('judul_halaman','produk'); ?>

<?php $__env->startSection('konten'); ?>


<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url(<?php echo e(asset('aspiration/images/susu1.jpg')); ?>);" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
      <div class="col-md-9 ftco-animate pb-5 text-center">
        <h2 class="mb-3 bread">Produk</h2>
        <p class="">Untuk membantu dalam pengembangan pantiasuhan anda dapat juga membeli produk dari panti kami</p>
        <a class="btn btn-success btn-xl js-scroll-trigger" href="#produk">Lihat produk</a>
      </div>
    </div>
  </div>
</section>

<section class="ftco-section ftco-causes">
  <div class="container" id="produk">
    <div class="row">
      <?php if($data->count() > 0): ?>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <div class="causes causes-2 text-left ftco-animate">
          <div class="img" style="background-image: url(<?php echo e(asset($d->image)); ?>);"></div>
          <h2><?php echo e($d->name); ?></h2>

          <div class="causes causes-2 text-right ftco-animate">
            <p><a href="<?php echo e(route('produk_detail',['id'=>$d->id])); ?>" class="btn btn-primary py-2 px-3">Read more</a></p>

          </div>
        </div>

      </div>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>

    <h1 style="color:var(--teal);">produk tidak ada</h1>

    <?php endif; ?>



    <div class="row mt-5">
      <div class="col text-center">
        <div class="block-27">
          <ul>
            <li class=""><?php echo e($data->links()); ?></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<script src="<?php echo e(asset('aspiration/js/buttonscroll.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/produk.blade.php ENDPATH**/ ?>