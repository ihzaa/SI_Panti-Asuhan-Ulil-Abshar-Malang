

<?php $__env->startSection('CssTambahanBefore'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul_halaman','Tambah gambar'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active"><a href="<?php echo e(route('admin_produk')); ?>">Produk</a></li>
<li class="breadcrumb-item active">tambah gambar</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/summernote/summernote-bs4.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Data Produk<span class="text-danger">*</span>
                </h3>
            </div>
            <div class="card-body" id="card-body-atas">
                <div class="row">
                    <div class="col-md-8 d-flex">
                        <div class="form-group col-md-12 my-auto">
                            <form action="<?php echo e(route('admin_tambah_gambar_produk',['id'=>$data['produk']->id])); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="imgInp" name="image">
                                    <label class="custom-file-label" for="imgInp">tambah gambar</label>

                                    <small class="form-text text-muted">- Ukuran max 256KB</small>
                                    <small class="form-text text-muted">- Harus berupa gambar (format: jpg, jpeg, svg,
                                        png , dll)</small>
                                </div>

                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <row>
                            <button class="btn btn-primary btn-block" type="submit" style="height: 40px;">tambah</button>
                        </row>
                        </form>
                    </div>




                </div>







                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card" id="card_gambar">



                                <div class="card-body">
                                    <table id="tabel_gambar" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>gambar</th>

                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data['gambar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="gambar<?php echo e($d->id); ?>">
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td class="text-center"><img src="<?php echo e(asset($d->image)); ?>" alt="" width="100">
                                                </td>

                                                <td class="text-center">

                                                    <button class="btn btn-sm btn-danger btn-hapus" data-id="<?php echo e($d->id); ?>" data-toggle="tooltip" data-placement="bottom" title="Hapus"><i class="fas fa-trash"></i></button>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>


    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('JsTambahanAfter'); ?>
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vue.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/axios.min.js')); ?>"></script>
<script>
    $('#tabel_gambar').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": true,
        "responsive": true,
    });

    // Enable tooltips everywhere
    $(function() {
        $('[data-toggle="tooltip"]').tooltip()
    });

    $(".btn-hapus").on('click', function() {
        Swal.fire({
            title: 'hapus gambar',

            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.value) {
                $('#card_gambar').append(`
                <div class="overlay dark" id="loading">
                    <i class="fas fa-2x fa-sync-alt fa-spin"></i>
                </div>
                `);
                let id = $(this).data('id');
                let url = "<?php echo e(route('admin_hapus_gambar',':__id')); ?>";
                url = url.replace(':__id', id);
                fetch(url)
                    .then(() => {
                        Swal.fire(
                            'Terhapus!',
                            'gambar telah terhapus.',
                            'success'
                        );
                        $("#gambar" + id).remove();
                        $('#card_gambar #loading').remove();
                    })
                    .catch(err => {
                        console.log(err);
                    });
            }
        });
    });
</script>
<?php if(Session::get('icon')): ?>
<script>
    Swal.fire({
        icon: "<?php echo e(Session::get('icon')); ?>",
        title: "<?php echo e(Session::get('title')); ?>",
        text: "<?php echo e(Session::get('text')); ?>",
    });
</script>
<?php endif; ?>

<script src="<?php echo e(asset('admin/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
<script>
    bsCustomFileInput.init();

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

    $("#imgInp").change(function() {
        readURL(this);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/admin/pages/produk/gambar-detail.blade.php ENDPATH**/ ?>