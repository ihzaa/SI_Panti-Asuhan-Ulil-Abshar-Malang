<?php $__env->startSection('JudulHalaman', 'Profil Anak'); ?>

<?php $__env->startSection('CssTambahanAfter'); ?>
<link rel="stylesheet" href="<?php echo e(asset('aspiration/css/style_profil_anak.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<?php $__env->startSection('foto_bg'); ?>
<section class="hero-wrap hero-wrap-2 js-fullheight"
    style="background-image: url(<?php echo e(asset('aspiration/images/bg_profil_anak.jpg')); ?>);" data-stellar-background-ratio="0.5">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('isiHeader'); ?>
    <h2 class="mb-3 bread">Profil Anak</h2>
    <p class="breadcrumbs"><span class="mr-2"><a href="/">Home <i class="ion-ios-arrow-forward"></i></a></span>
        <span>Profil Anak <i class="ion-ios-arrow-forward"></i></span></p>
    <?php $__env->stopSection(); ?>
    <?php echo $__env->make('frontend.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="ftco-section ftco-causes">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
        <div class="container">
            <?php if(count($data_anak) > 0): ?>
            <div class="data_anak">
                <?php echo $__env->make('frontend.pages.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php else: ?>
            <h1>Data anak asuh tidak tersedia</h1>
            <?php endif; ?>
        </div>

        
    </section>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('JsTambahanAfter'); ?>
    <script>
        $(function() {
    $('body').on('click', '.pagination a', function(e) {
        e.preventDefault();

        var url = $(this).attr('href');
        getArticles(url);
        window.history.pushState("", "", url);
    });

    function getArticles(url) {
        $.ajax({
            url : url
        }).done(function (data) {
            $('.data_anak').html(data);
        }).fail(function () {
            alert('Data anak could not be loaded.');
        });
    }
});
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/profil_anak.blade.php ENDPATH**/ ?>