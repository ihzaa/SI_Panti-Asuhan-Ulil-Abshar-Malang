


<?php $__env->startSection('judul_halaman','produk'); ?>

<?php $__env->startSection('konten'); ?>


<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url(<?php echo e(asset('aspiration/images/susu1.jpg')); ?>);" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
      <div class="col-md-9 ftco-animate pb-5 text-center">
        <h2 class="mb-3 bread">Produk Detail</h2>
        <a class="btn btn-success btn-xl js-scroll-trigger" href="#detail">Lihat produk</a>
      </div>
    </div>
  </div>
</section>

<section class="ftco-section ">
  <div class="container" id="detail">
    <div class="row d-flex">
      <div class="col-md-6 col-lg-5 ">

        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="img d-flex align-self-stretch align-items-center " src="<?php echo e(asset($data['produk']->image)); ?>" alt="First slide" height="500px">
            </div>
            <?php $__currentLoopData = $data['gambar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item">
              <img class="img d-flex align-self-stretch align-items-center  " src="<?php echo e(asset($d->image)); ?>" alt="Second slide" height="500px">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div>

      </div>
      <div class="col-md-6 col-lg-7 pl-lg-5 py-5">
        <div class="py-md-5">
          <div class="row justify-content-start pb-3">
            <div class="col-md-12 heading-section ftco-animate">

              <h2 class="mb-4" style="color='"><u><?php echo e($data['produk']->name); ?></u></h2>
              <h3>Deskirpsi :</h3>
              <p><?php echo e($data['produk']->desc); ?></p>

              <h3>harga :</h3>

              <h4>RP. <?php
                      $number = $data['produk']->price;
                      echo number_format("$number", 0, ",", ".")
                      ?></h4>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<script src="<?php echo e(asset('aspiration/js/buttonscroll.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/produk_detail.blade.php ENDPATH**/ ?>