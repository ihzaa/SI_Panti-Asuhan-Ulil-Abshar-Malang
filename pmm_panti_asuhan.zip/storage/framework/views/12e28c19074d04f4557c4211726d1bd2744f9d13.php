<div id='load' class="row el-element-overlay">
        
  
  <?php $__currentLoopData = $data_anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="el-card-item">
                <div class="el-card-avatar el-overlay-1"> 
                  <?php if($row->foto_path != ''): ?>
                    <div style="width: auto; height: 265px;">
                      <img style="width: auto; height: 100%;" src="<?php echo e(asset($row->foto_path)); ?>" alt="user">
                    </div>
                  <?php else: ?>
                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="user">
                  <?php endif; ?>
                    <div class="el-overlay">
                        <ul class="list-style-none el-info">
                          <div>
                            Alamat Asal
                            Malang
                          </div>
                          <div>
                            Umur
                            <?php echo e($row->umur); ?> Tahun
                          </div>
                          <div>
                            Jenis Kelamin
                            <?php if($row->jenis_kelamin == 0): ?>
                                Perempuan
                            <?php else: ?>
                              Laki - Laki
                            <?php endif; ?>
                          </div>
                            
                        </ul>
                    </div>
                </div>
                <div class="el-card-content">
                <h4 class="m-b-0"><?php echo e($row->nama); ?></h4> <span class="text-muted"><?php echo e($row->sekolah); ?></span>
                </div>
            </div>
        </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  
</div>
<?php echo e($data_anak->links()); ?><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/pagination.blade.php ENDPATH**/ ?>