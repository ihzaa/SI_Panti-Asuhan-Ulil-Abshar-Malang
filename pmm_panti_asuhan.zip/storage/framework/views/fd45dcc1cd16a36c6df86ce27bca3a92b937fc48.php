<?php $__env->startSection('judul_halaman','Blog'); ?>

<?php $__env->startSection('konten'); ?>
<?php $__env->startSection('foto_bg'); ?>
<section class="hero-wrap hero-wrap-2 js-fullheight"
    style="background-image: url(<?php echo e(asset('aspiration/images/bg_blog_contact3.JPG')); ?>);" data-stellar-background-ratio="0.5">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('isiHeader'); ?>
    <h2 class="mb-3 bread">Blog</h2>
    <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(route('home')); ?>">Beranda <i
                    class="ion-ios-arrow-forward"></i></a></span>
        <span>Blog <i class="ion-ios-arrow-forward"></i></span></p>
    <?php $__env->stopSection(); ?>
    <?php echo $__env->make('frontend.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="ftco-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 ftco-animate">
                    <div class="row">
                        <?php if(count($data['blogs']) == 0): ?>
                        <div class="col-md-12 text-center">
                            Blog tidak ada
                        </div>
                        <?php endif; ?>
                        <?php $__currentLoopData = $data['blogs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12 d-flex ftco-animate">
                            <div class="blog-entry align-self-stretch d-md-flex">
                                <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>" class="block-20"
                                    style="background-image: url('<?php echo e(asset($d->sampul_foto)); ?>');">
                                </a>
                                <div class="text d-block pl-md-4">
                                    <div class="meta mb-3">
                                        <div><a
                                                href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>"><?php echo e(\Carbon\Carbon::parse($d->created_at)->formatLocalized("%A, %d %B %Y")); ?></a>
                                        </div>
                                        <div><a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>">-
                                                <?php echo e($d->users->nama); ?></a></div>
                                    </div>
                                    <h3 class="heading"><a
                                            href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>"><?php echo e($d->judul); ?></a>
                                    </h3>
                                    <p><?php echo e(preg_replace('/<[^>]*>/', '', substr($d->konten,0,150))); ?></p>
                                    <p><a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>"
                                            class="btn btn-primary py-2 px-3">Read more</a></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($data['blogs']->links()); ?>

                        
                    </div>
                </div> <!-- .col-md-8 -->
                <div class="col-lg-4 sidebar ftco-animate">
                    <?php echo $__env->make('frontend.pages.Blog.Components.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('frontend.pages.Blog.Components.categoris', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                </div>
            </div>
        </div>
    </section> <!-- .section -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('JsTambahanAfter'); ?>
    <script src="<?php echo e(asset('js/pages/blog-search.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/Blog/blog.blade.php ENDPATH**/ ?>