<div class="sidebar-box ftco-animate">
    <h3 class="heading-2">Tag Cloud</h3>
    <div class="tagcloud">
        <a href="#" class="tag-cloud-link">donate</a>
        <a href="#" class="tag-cloud-link">charity</a>
        <a href="#" class="tag-cloud-link">non-profit</a>
        <a href="#" class="tag-cloud-link">organization</a>
        <a href="#" class="tag-cloud-link">child</a>
        <a href="#" class="tag-cloud-link">abuse</a>
        <a href="#" class="tag-cloud-link">help</a>
        <a href="#" class="tag-cloud-link">volunteer</a>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/Blog/Components/tags.blade.php ENDPATH**/ ?>