<?php $__env->startSection('judul_halaman',$data['blog']->judul); ?>

<?php $__env->startSection('konten'); ?>
<?php $__env->startSection('isiHeader'); ?>
<h2 class="mb-3 bread">Blog Details</h2>
<p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow-forward"></i></a></span>
    <span>Blog Single <i class="ion-ios-arrow-forward"></i></span></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="ftco-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 ftco-animate">
                <h2 class="mb-3"><?php echo e($data['blog']->judul); ?></h2>
                <?php
                    $d = $data['blog']->konten;
                    echo "<p>$d</p>";
                ?>
                

                


                

            </div> <!-- .col-md-8 -->
            <div class="col-lg-4 sidebar ftco-animate">
                <?php echo $__env->make('frontend.pages.Blog.Components.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('frontend.pages.Blog.Components.categoris', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                

            </div>

        </div>
    </div>
</section> <!-- .section -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JsTambahanAfter'); ?>
<script src="<?php echo e(asset('js/pages/blog-search.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/Blog/single-blog.blade.php ENDPATH**/ ?>