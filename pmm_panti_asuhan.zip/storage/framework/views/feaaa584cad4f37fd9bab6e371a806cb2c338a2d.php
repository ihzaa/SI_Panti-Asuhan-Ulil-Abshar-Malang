<section class="ftco-section">
  <div class="container">
    <div class="row justify-content-center pb-5">
      <div class="col-md-10 heading-section text-center ftco-animate">
        <h2 class="mb-4">Blog Saat Ini</h2>
        
      </div>
    </div>
    <div class="row">
      <?php if(count($blogs) == 0): ?>
        <div class="col-md-12 text-center" style="font-size: 1.3rem !important;">
            Blog tidak ada
        </div>
      <?php endif; ?>
      <div class="col-md-6">
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($key < 1): ?>
            <div class="blog-entry align-self-stretch ftco-animate">
              <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>" class="block-20 img" style="background-image: url('<?php echo e(asset($d->sampul_foto)); ?>');">
              </a>
              <div class="text text-2 bg-light">
                <h3 class="heading mb-2">
                  <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>"><?php echo e($d->judul); ?></a>
                </h3>
                <div class="meta mb-2">
                  <div>
                    <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>">
                      <?php echo e(\Carbon\Carbon::parse($d->created_at)->formatLocalized("%A, %d %B %Y")); ?>

                    </a>
                  </div>
                  <div>
                    <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>">
                        <?php echo e($d->users->nama); ?>

                    </a>
                  </div>
                  
                </div>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="col-md-6">
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($key > 0): ?>
            <div class="blog-entry align-self-stretch d-md-flex bg-light p-3 align-items-center d-flex ftco-animate">
              <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>" class="block-20 thumb" style="background-image: url('<?php echo e(asset($d->sampul_foto)); ?>');">
              </a>
              <div class="text text-thumb d-block pl-2 pl-md-4">
                <h3 class="heading mb-2">
                  <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>"><?php echo e($d->judul); ?></a>
                </h3>
                <div class="meta">
                  <div>
                    <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>">
                      <?php echo e(\Carbon\Carbon::parse($d->created_at)->formatLocalized("%A, %d %B %Y")); ?>

                    </a>
                  </div>
                  <div>
                    <a href="<?php echo e(route('frontend_single_blog',['id'=>$d->id])); ?>">
                      <?php echo e($d->users->nama); ?>

                    </a>
                  </div>
                  
                </div>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
      </div>
    </div>
    
  </div>
</section><?php /**PATH C:\xampp\htdocs\pmm_panti_asuhan\resources\views/frontend/pages/Home/Components/recent_blog.blade.php ENDPATH**/ ?>