@yield('foto_bg')
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
            <div class="col-md-9 ftco-animate pb-5 text-center">
                @yield('isiHeader')
            </div>
        </div>
    </div>
</section>
