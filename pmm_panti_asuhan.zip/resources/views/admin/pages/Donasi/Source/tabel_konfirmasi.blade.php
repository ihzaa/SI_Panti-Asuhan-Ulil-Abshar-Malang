<div class="card card_tabel">
  <div class="card-header">
    <h3 class="card-title">Konfirmasi Donasi</h3>

    <div class="card-tools">
      <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
        <i class="fas fa-minus"></i></button>
    </div>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <table id="tabel_donasi" class="table table-bordered table-hover">
      <thead>
        <tr>
          <th>Tgl Dibuat</th>
          <th>Email</th>
          <th>Nama Donatur</th>
          <th>Nama Alias</th>
          <th>Donasi</th>
          <th>Bank</th>
          <th style="width: 10%">Aksi</th>
        </tr>
      </thead>
      <tbody>
        
      </tbody>
      <tfoot>
        <tr>
          <th>Tgl Dibuat</th>
          <th>Email</th>
          <th>Nama Donatur</th>
          <th>Nama Alias</th>
          <th>Donasi</th>
          <th>Bank</th>
          <th style="width: 10%">Aksi</th>
        </tr>
      </tfoot>
    </table>
  </div>
  <!-- /.card-body -->
</div>