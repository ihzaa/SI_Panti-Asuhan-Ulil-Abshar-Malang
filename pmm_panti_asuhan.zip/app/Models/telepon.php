<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class telepon extends Model
{
    protected $fillable = ['no_telp','key'];
}
