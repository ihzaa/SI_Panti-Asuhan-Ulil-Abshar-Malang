<?php

namespace App\Models\Frontend;

use Illuminate\Database\Eloquent\Model;

class DonasiMasuk extends Model
{
  protected $table = 'donasi_masuks';
  protected $fillable = ['donasi_id'];

  
}
