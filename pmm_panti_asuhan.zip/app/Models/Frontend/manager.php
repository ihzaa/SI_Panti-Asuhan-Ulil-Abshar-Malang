<?php

namespace App\Models\Frontend;

use Illuminate\Database\Eloquent\Model;

class manager extends Model
{
    //
}
