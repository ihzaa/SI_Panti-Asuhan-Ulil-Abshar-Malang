<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class blog_foto extends Model
{
    protected $fillable = ['path', 'blog_id'];
}
