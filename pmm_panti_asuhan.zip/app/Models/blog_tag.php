<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class blog_tag extends Model
{
    //
}
