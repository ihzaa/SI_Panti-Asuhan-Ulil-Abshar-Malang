<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gambar_detail extends Model
{
    public $table = "gambar_details";
}
