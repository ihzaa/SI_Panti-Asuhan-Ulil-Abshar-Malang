<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/produk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'produk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/all/pengeluaran/get/tahun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all_user_get_tahun_Pengeluaran',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/produk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_produk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/produk/tambah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tampil_halaman_tambah_produk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tambah_produk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/pengeluaran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_pengeluaran',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/pengeluaran/tambah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tampil_halaman_tambah_pengeluaran',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tambah_pengeluaran_dong',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'frontend_blog_index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/contact' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'frontend_contact',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login_admin_get',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'login_admin_post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout_admin',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/all/donasi/get/tahun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all_user_get_tahun_donasi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/testing' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xMV9t5zzytciHNMS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/pages/blog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_pages_blog_index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/pages/blog/tambah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tampil_halaman_tambah_blog',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tambah_blog',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/pages/blog/kategori/tambah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tambah_blog_kategori',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/kategori/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_get_all_kategori',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/kelola-akun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_kelola_akun',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/ubah-pass' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_ubah_password',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/ubah-nama' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_ubah_nama',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/setting/nomer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_setting_nomer_wa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/setting/apikey' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_setting_api_key',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/setting/get_nomer_wa_key' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_setting_get_data',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/pengeluaran/get/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_get_all_pengeluaran_dong',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/pengeluaran/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_edit_pengeluaran_dong',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profil_anak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profil_anak',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profil_anak/pagination' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profil_anak_pagination',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/donasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'send_donasi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/donasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_pages_donasi_index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/donasi/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_pages_donasi_add',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/donasi_masuk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_pages_donasi_masuk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/profil_anak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_profil_anak',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/profil_anak/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_profil_anak_create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/profil_anak/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_profil_anak_update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/setting' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_setting',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/setting/add_bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_setting_add_bank',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/setting/update_bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_setting_bank_update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'about',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/manager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_manager',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/manager/tambah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tampil_halaman_tambah_pengurus',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tambah_pengurus',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/fasilitas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_fasilitas',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/adm1n/fasilitas/tambah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tampil_halaman_tambah_fasilitas',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tambah_fasilitas',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/produk/([^/]++)(*:23)|/a(?|ll/(?|pengeluaran/(?|get/month/([^/]++)(*:74)|download/(?|tahun/([^/]++)(*:107)|bulan/([^/]++)/([^/]++)(*:138)))|donasi/(?|get/month/([^/]++)(*:176)|download/(?|tahun/([^/]++)(*:210)|bulan/([^/]++)/([^/]++)(*:241))))|dm1n/(?|p(?|ro(?|duk/(?|delete/([^/]++)(*:291)|edit/([^/]++)(?|(*:315))|gambar/([^/]++)(?|(*:342))|hapus/([^/]++)(*:365))|fil_anak/(?|edit/([^/]++)(*:399)|delete/([^/]++)(*:422)))|engeluaran/(?|delete/([^/]++)(*:461)|edit/([^/]++)(?|(*:485))|hapus/([^/]++)(*:508))|ages/blog/(?|delete/([^/]++)(*:545)|edit/([^/]++)(?|(*:569))))|kategori/(?|hapus/([^/]++)(*:606)|edit/([^/]++)(*:627))|donasi/(?|d(?|ownload/(?|tahun/([^/]++)(*:675)|bulan/([^/]++)/([^/]++)(*:706))|elete/([^/]++)(*:729))|konfirmasi/(?|([^/]++)(*:760)|batal/([^/]++)(*:782)))|setting/(?|edit_bank/([^/]++)(*:821)|delete_bank/([^/]++)(*:849))|manager/(?|delete/([^/]++)(*:884)|edit/([^/]++)(?|(*:908)))|fasilitas/(?|delete/([^/]++)(*:946)|edit/([^/]++)(?|(*:970)))))|/cek/pengeluaran/download/(?|tahun/([^/]++)(*:1025)|bulan/([^/]++)/([^/]++)(*:1057))|/blog/(?|cari/([^/]++)(*:1089)|kategori/([^/]++)(*:1115)|([^/]++)(*:1132)))/?$}sDu',
    ),
    3 => 
    array (
      23 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'produk_detail',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      74 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all_user_get_bulan_Pengeluaran_per_tahun',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      107 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all_user_downlaod_Pengeluaran_tahun',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      138 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all_user_downlaod_Pengeluaran_bulan',
          ),
          1 => 
          array (
            0 => 'month',
            1 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      176 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all_user_get_bulan_donasi_per_tahun',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      210 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all_user_downlaod_donasi_tahun',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      241 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'all_user_downlaod_donasi_bulan',
          ),
          1 => 
          array (
            0 => 'month',
            1 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      291 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_hapus_produk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      315 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tampil_edit_produk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_edit_produk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      342 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_gambar_produk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tambah_gambar_produk',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      365 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_hapus_gambar',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      399 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_profil_anak_edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      422 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_profil_anak_delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      461 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_hapus_pengeluaran',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      485 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tampil_edit_pengeluaran',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_edit_pengeluaran',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      508 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_hapus_pengeluaran_dong',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      545 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_hapus_blog',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      569 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_edit_blog_index',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_edit_blog',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      606 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_hapus_blog_kategori',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      627 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_edit_blog_kategori',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      675 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_downlaod_donasi_tahun',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      706 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_downlaod_donasi_bulan',
          ),
          1 => 
          array (
            0 => 'month',
            1 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      729 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_hapus_donasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      760 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_donasi_konfirmasi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      782 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_donasi_konfirmasi_cancel',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      821 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_setting_bank_edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      849 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_setting_bank_delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      884 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_hapus_pengurus',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      908 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tampil_edit_pengurus',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_edit_pengurus',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      946 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_hapus_fasilitas',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      970 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin_tampil_edit_fasilitas',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin_edit_fasilitas',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1025 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cek_downlaod_Pengeluaran_tahun',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1057 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cek_downlaod_Pengeluaran_bulan',
          ),
          1 => 
          array (
            0 => 'month',
            1 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1089 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'frontend_blog_cari',
          ),
          1 => 
          array (
            0 => 'cari',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1115 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'frontend_blog_per_kategori',
          ),
          1 => 
          array (
            0 => 'kat',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'frontend_single_blog',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\frontend\\HomeController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'produk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'produk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\ProdukController@index',
        'controller' => 'App\\Http\\Controllers\\frontend\\ProdukController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'produk_detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'produk/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\ProdukController@produk_detail',
        'controller' => 'App\\Http\\Controllers\\frontend\\ProdukController@produk_detail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'produk_detail',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all_user_get_tahun_Pengeluaran' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all/pengeluaran/get/tahun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@getAllYear',
        'controller' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@getAllYear',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'all_user_get_tahun_Pengeluaran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all_user_get_bulan_Pengeluaran_per_tahun' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all/pengeluaran/get/month/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@getAllMonthByYear',
        'controller' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@getAllMonthByYear',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'all_user_get_bulan_Pengeluaran_per_tahun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all_user_downlaod_Pengeluaran_tahun' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all/pengeluaran/download/tahun/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@downloadPengeluaranByYear',
        'controller' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@downloadPengeluaranByYear',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'all_user_downlaod_Pengeluaran_tahun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all_user_downlaod_Pengeluaran_bulan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all/pengeluaran/download/bulan/{month}/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@downloadPengeluaranByMonth',
        'controller' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@downloadPengeluaranByMonth',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'all_user_downlaod_Pengeluaran_bulan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'cek_downlaod_Pengeluaran_tahun' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cek/pengeluaran/download/tahun/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@cek',
        'controller' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@cek',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'cek_downlaod_Pengeluaran_tahun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'cek_downlaod_Pengeluaran_bulan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cek/pengeluaran/download/bulan/{month}/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@cekb',
        'controller' => 'App\\Http\\Controllers\\frontend\\PengeluaranController@cekb',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'cek_downlaod_Pengeluaran_bulan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_produk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/produk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProdukController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProdukController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tampil_halaman_tambah_produk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/produk/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProdukController@HalamanTambah',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProdukController@HalamanTambah',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tampil_halaman_tambah_produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tambah_produk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/produk/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProdukController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProdukController@create',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tambah_produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_hapus_produk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/produk/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProdukController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProdukController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_hapus_produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tampil_edit_produk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/produk/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProdukController@tampilEditProduk',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProdukController@tampilEditProduk',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tampil_edit_produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_edit_produk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/produk/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProdukController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProdukController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_edit_produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_gambar_produk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/produk/gambar/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProdukController@tampilgambarProduk',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProdukController@tampilgambarProduk',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_gambar_produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tambah_gambar_produk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/produk/gambar/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProdukController@tambahgambar',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProdukController@tambahgambar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tambah_gambar_produk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_hapus_gambar' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/produk/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProdukController@hapusGambar',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProdukController@hapusGambar',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_hapus_gambar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_pengeluaran' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pengeluaran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_pengeluaran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tampil_halaman_tambah_pengeluaran' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pengeluaran/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@HalamanTambah',
        'controller' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@HalamanTambah',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tampil_halaman_tambah_pengeluaran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tambah_pengeluaran_dong' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/pengeluaran/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@tambah',
        'controller' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@tambah',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tambah_pengeluaran_dong',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_hapus_pengeluaran' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pengeluaran/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@destroy',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_hapus_pengeluaran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tampil_edit_pengeluaran' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pengeluaran/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@tampilEdit',
        'controller' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@tampilEdit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tampil_edit_pengeluaran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_edit_pengeluaran' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/pengeluaran/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_edit_pengeluaran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'frontend_blog_index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\BlogController@index',
        'controller' => 'App\\Http\\Controllers\\frontend\\BlogController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'frontend_blog_index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'frontend_blog_cari' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/cari/{cari}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\BlogController@cari',
        'controller' => 'App\\Http\\Controllers\\frontend\\BlogController@cari',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'frontend_blog_cari',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'frontend_blog_per_kategori' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/kategori/{kat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\BlogController@kategori',
        'controller' => 'App\\Http\\Controllers\\frontend\\BlogController@kategori',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'frontend_blog_per_kategori',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'frontend_single_blog' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blog/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\BlogController@single_blog',
        'controller' => 'App\\Http\\Controllers\\frontend\\BlogController@single_blog',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'frontend_single_blog',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'frontend_contact' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'contact',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\ContactController@index',
        'controller' => 'App\\Http\\Controllers\\frontend\\ContactController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'frontend_contact',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login_admin_get' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AdminLoginController@loginGet',
        'controller' => 'App\\Http\\Controllers\\Auth\\AdminLoginController@loginGet',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login_admin_get',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login_admin_post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AdminLoginController@loginPost',
        'controller' => 'App\\Http\\Controllers\\Auth\\AdminLoginController@loginPost',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login_admin_post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'logout_admin' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\AdminLoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\AdminLoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'logout_admin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all_user_get_tahun_donasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all/donasi/get/tahun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\DonasiController@getAllYear',
        'controller' => 'App\\Http\\Controllers\\frontend\\DonasiController@getAllYear',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'all_user_get_tahun_donasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all_user_get_bulan_donasi_per_tahun' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all/donasi/get/month/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\DonasiController@getAllMonthByYear',
        'controller' => 'App\\Http\\Controllers\\frontend\\DonasiController@getAllMonthByYear',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'all_user_get_bulan_donasi_per_tahun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all_user_downlaod_donasi_tahun' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all/donasi/download/tahun/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\DonasiController@downloadDonasiByYear',
        'controller' => 'App\\Http\\Controllers\\frontend\\DonasiController@downloadDonasiByYear',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'all_user_downlaod_donasi_tahun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'all_user_downlaod_donasi_bulan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all/donasi/download/bulan/{month}/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\DonasiController@downloadDonasiByMonth',
        'controller' => 'App\\Http\\Controllers\\frontend\\DonasiController@downloadDonasiByMonth',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'all_user_downlaod_donasi_bulan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xMV9t5zzytciHNMS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/testing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DonationController@testing',
        'controller' => 'App\\Http\\Controllers\\Admin\\DonationController@testing',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'generated::xMV9t5zzytciHNMS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_pages_blog_index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pages/blog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_pages_blog_index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_hapus_blog' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pages/blog/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@hapus',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@hapus',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_hapus_blog',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tampil_halaman_tambah_blog' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pages/blog/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@tampilHalamanTambah',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@tampilHalamanTambah',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tampil_halaman_tambah_blog',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tambah_blog' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/pages/blog/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@tambahBlog',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@tambahBlog',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tambah_blog',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_edit_blog_index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pages/blog/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@editBlogIndex',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@editBlogIndex',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_edit_blog_index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_edit_blog' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/pages/blog/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@editBlog',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@editBlog',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_edit_blog',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tambah_blog_kategori' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/pages/blog/kategori/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@tambahKategori',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@tambahKategori',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tambah_blog_kategori',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_get_all_kategori' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/kategori/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@getAllKategori',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@getAllKategori',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_get_all_kategori',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_hapus_blog_kategori' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/kategori/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@hapusKategori',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@hapusKategori',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_hapus_blog_kategori',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_edit_blog_kategori' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/kategori/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BlogController@editKategori',
        'controller' => 'App\\Http\\Controllers\\Admin\\BlogController@editKategori',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_edit_blog_kategori',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_kelola_akun' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/kelola-akun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AkunController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AkunController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_kelola_akun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_ubah_password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/ubah-pass',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AkunController@ubahPass',
        'controller' => 'App\\Http\\Controllers\\Admin\\AkunController@ubahPass',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_ubah_password',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_ubah_nama' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/ubah-nama',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AkunController@ubahNama',
        'controller' => 'App\\Http\\Controllers\\Admin\\AkunController@ubahNama',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_ubah_nama',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_setting_nomer_wa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/setting/nomer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@aturNomerWa',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@aturNomerWa',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_setting_nomer_wa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_setting_api_key' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/setting/apikey',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@aturApiKey',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@aturApiKey',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_setting_api_key',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_setting_get_data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/setting/get_nomer_wa_key',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@getDataAdmin',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@getDataAdmin',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_setting_get_data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_downlaod_donasi_tahun' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/donasi/download/tahun/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\DonasiController@downloadDonasiByYear',
        'controller' => 'App\\Http\\Controllers\\frontend\\DonasiController@downloadDonasiByYear',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_downlaod_donasi_tahun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_downlaod_donasi_bulan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/donasi/download/bulan/{month}/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\DonasiController@downloadDonasiByMonth',
        'controller' => 'App\\Http\\Controllers\\frontend\\DonasiController@downloadDonasiByMonth',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_downlaod_donasi_bulan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_get_all_pengeluaran_dong' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pengeluaran/get/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@getAll',
        'controller' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@getAll',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_get_all_pengeluaran_dong',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_edit_pengeluaran_dong' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/pengeluaran/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@edit_dong',
        'controller' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@edit_dong',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_edit_pengeluaran_dong',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_hapus_pengeluaran_dong' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/pengeluaran/hapus/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@hapus_dong',
        'controller' => 'App\\Http\\Controllers\\Admin\\PengeluaranController@hapus_dong',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_hapus_pengeluaran_dong',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'profil_anak' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profil_anak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\ProfilAnakController@index',
        'controller' => 'App\\Http\\Controllers\\frontend\\ProfilAnakController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'profil_anak',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'profil_anak_pagination' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profil_anak/pagination',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\ProfilAnakController@fetch_data',
        'controller' => 'App\\Http\\Controllers\\frontend\\ProfilAnakController@fetch_data',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'profil_anak_pagination',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'send_donasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'donasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\HomeController@donation',
        'controller' => 'App\\Http\\Controllers\\frontend\\HomeController@donation',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'send_donasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_pages_donasi_index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/donasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DonationController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DonationController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_pages_donasi_index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_pages_donasi_add' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/donasi/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DonationController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\DonationController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_pages_donasi_add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_pages_donasi_masuk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/donasi_masuk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DonationController@donasi_masuk',
        'controller' => 'App\\Http\\Controllers\\Admin\\DonationController@donasi_masuk',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_pages_donasi_masuk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_donasi_konfirmasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/donasi/konfirmasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DonationController@confirmation',
        'controller' => 'App\\Http\\Controllers\\Admin\\DonationController@confirmation',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_donasi_konfirmasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_donasi_konfirmasi_cancel' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/donasi/konfirmasi/batal/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DonationController@cancel_confirmation',
        'controller' => 'App\\Http\\Controllers\\Admin\\DonationController@cancel_confirmation',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_donasi_konfirmasi_cancel',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_hapus_donasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/donasi/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DonationController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\DonationController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_hapus_donasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_profil_anak' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/profil_anak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_profil_anak',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_profil_anak_create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/profil_anak/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@store',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_profil_anak_create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_profil_anak_edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/profil_anak/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_profil_anak_edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_profil_anak_update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/profil_anak/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_profil_anak_update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_profil_anak_delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/profil_anak/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProfilAnakController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_profil_anak_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_setting' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/setting',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_setting',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_setting_add_bank' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/setting/add_bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@add_bank',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@add_bank',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_setting_add_bank',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_setting_bank_edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/setting/edit_bank/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@bank_edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@bank_edit',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_setting_bank_edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_setting_bank_update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/setting/update_bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@bank_update',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@bank_update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_setting_bank_update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_setting_bank_delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/setting/delete_bank/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@bank_delete',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@bank_delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_setting_bank_delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'about' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\frontend\\AboutController@index',
        'controller' => 'App\\Http\\Controllers\\frontend\\AboutController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'about',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_manager' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/manager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManagerController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManagerController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_manager',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tampil_halaman_tambah_pengurus' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/manager/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManagerController@tampilHalamanTambah',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManagerController@tampilHalamanTambah',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tampil_halaman_tambah_pengurus',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tambah_pengurus' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/manager/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManagerController@tambahData',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManagerController@tambahData',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tambah_pengurus',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_hapus_pengurus' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/manager/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManagerController@hapus',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManagerController@hapus',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_hapus_pengurus',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tampil_edit_pengurus' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/manager/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManagerController@tampilEditPengurus',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManagerController@tampilEditPengurus',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tampil_edit_pengurus',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_edit_pengurus' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/manager/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ManagerController@editPengurus',
        'controller' => 'App\\Http\\Controllers\\Admin\\ManagerController@editPengurus',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_edit_pengurus',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_fasilitas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/fasilitas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FasilitasController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\FasilitasController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_fasilitas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tampil_halaman_tambah_fasilitas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/fasilitas/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FasilitasController@tampilHalamanTambah',
        'controller' => 'App\\Http\\Controllers\\Admin\\FasilitasController@tampilHalamanTambah',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tampil_halaman_tambah_fasilitas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tambah_fasilitas' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/fasilitas/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FasilitasController@tambahData',
        'controller' => 'App\\Http\\Controllers\\Admin\\FasilitasController@tambahData',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tambah_fasilitas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_hapus_fasilitas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/fasilitas/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FasilitasController@hapus',
        'controller' => 'App\\Http\\Controllers\\Admin\\FasilitasController@hapus',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_hapus_fasilitas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_tampil_edit_fasilitas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'adm1n/fasilitas/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FasilitasController@tampilEditFasilitas',
        'controller' => 'App\\Http\\Controllers\\Admin\\FasilitasController@tampilEditFasilitas',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_tampil_edit_fasilitas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'admin_edit_fasilitas' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'adm1n/fasilitas/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FasilitasController@editFasilitas',
        'controller' => 'App\\Http\\Controllers\\Admin\\FasilitasController@editFasilitas',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/adm1n',
        'where' => 
        array (
        ),
        'as' => 'admin_edit_fasilitas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
